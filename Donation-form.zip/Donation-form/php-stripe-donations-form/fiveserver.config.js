module.exports = {
    php: "C:\\xampp\\php\\php.exe"   
  }