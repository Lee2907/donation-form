<?php
// config/config.php

$configuration = [
    'database' => [
        'hostname' => 'localhost',
        'port'     => 3306,
        'name' => 'card_name',
        'address' => 'db_address',
        'city'  =>  'db_city',
        'state' => 'db_secret_state',
        'zipcode'  =>  'db_zipcode',
    ]
];